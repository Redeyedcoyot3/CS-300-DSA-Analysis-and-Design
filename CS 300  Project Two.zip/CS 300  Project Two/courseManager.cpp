#include <iostream>
#include <vector>
#include <climits>
#include <limits>
#include <algorithm> 
#include <sstream>

#include "CSVparser.hpp"

/*
Dylan Cavazos
CS 300 Data Structures & Algorithms; Module Seven - Project Two
December 4th - 10th, 2023
SNHU
*/

using namespace std;

// Setting the default size to 100 to be used by table size
const unsigned int DEFAULT_SIZE = 100;

// Define a structure to hold course info
struct Course {
    string courseNumber;
    string title;
    vector<string> prerequisites;

    // Default constructor
    Course() {
        courseNumber = "";
        title = "";
    };

    // Constructor for Course
    Course(string number, string name) : courseNumber(number), title(name) {}
};

// Class for hashtable
class HashTable {
private:
    struct Node {
        Course course;
        unsigned int key;
        Node* next;

        // Default constructor
        Node() {
            key = UINT_MAX;
            next = nullptr;
        }

        // Initialize with a course and key
        Node(Course aCourse, unsigned int aKey) : Node() {
            course = aCourse;
            key = aKey;
        }
    };

    // Private function declarations
    Node* findNode(const string& courseNumber);
    void printPrerequisites(const vector<string>& prerequisites);
    vector<Node> nodes;
    unsigned int tableSize = DEFAULT_SIZE;
    unsigned int hash(const string& key);

public:

    // Public function declarations
    HashTable();
    HashTable(unsigned int size);
    ~HashTable();
    void insertCourse(const Course& course);
    void loadCourses(const string& filePath);
    void printAllCourses();
    void printCourse(const string& courseNumber);
    Course searchCourse(const string& courseNumber);
};

// Constructor for HashTable
HashTable::HashTable() {
    nodes.resize(tableSize);
}

// Constructor for specifying the size of the table
HashTable::HashTable(unsigned int size) : tableSize(size) {
    nodes.resize(size);
}

// Destructor
HashTable::~HashTable() {
    // Iterate over each node in the hash table
    for (auto& node : nodes) {
        // Start with the first node in the linked list
        Node* current = node.next;

        // Traverse the linked list of nodes
        while (current != nullptr) {

            // Save the next node in the list
            Node* next = current->next;

            // Delete the current node
            delete current;

            // Move to the next node in the list
            current = next;
        }
    }

    // Clear the vector of nodes
    nodes.clear();
}

// Calculate the hash value using a key for a string parameter
unsigned int HashTable::hash(const string& key) {

    // Initialize the hash value
    size_t hash = 0;

    // Iterate through each character in the key
    for (char ch : key) {

        // Update the hash value using a simple hash function
        // Multiply the current hash value by 31 and add the ASCII value of the character
        hash = (hash * 31) + static_cast<size_t>(ch);
    }

    // Return the hash value modulo the table size
    return hash % tableSize;
}

// Function that finds a node in the hash table using the coursenumber 
HashTable::Node* HashTable::findNode(const string& courseNumber) {
    // Generate the hash key using the courseNumber as input
    unsigned int key = hash(courseNumber);

    // Start at the head of the linked list using the computed hash key
    Node* current = &nodes[key];

    // Iterate through the linked list using the computed hash key
    while (current != nullptr) {

        // Check if the course number of the current node matches the target course number
        if (current->course.courseNumber == courseNumber) {

            // Return the pointer to the found node
            return current;
        }
        // Move to the next node in the linked list
        current = current->next;
    }
    // If the loop completes and doesn't find a match, then return nullptr
    return nullptr;
}

// Function to insert a course into hash table
void HashTable::insertCourse(const Course& course) {
    // Generate a hash key using the course number
    unsigned int key = hash(course.courseNumber);

    // Start at the head of the linked list at the computed hash key
    Node* current = &nodes[key];

    // While loop to iterate through the linked list
    while (current != nullptr) {

        // Check first if current node is empty
        if (current->key == UINT_MAX) {

            // If it is empty, the insert the course information
            current->course = course;
            current->key = key;
            return;
        } 
        
        else if (current->course.courseNumber == course.courseNumber) {

            // If course already exists, the update it. 
            current->course = course;
            return;
        } 
        
        else {

            // Move to the next node in the linked list
            current = current->next;
        }
    }

    // If we reach here, there's no empty slot, create a new node
    Node* newNode = new Node(course, key);

    // set current to the value of the head of the linked list at the hash key
    current = &nodes[key];

    // Get to the end of the linked list
    while (current->next != nullptr) {
        current = current->next;
    }

    // Add the new node to the end of the linked list
    current->next = newNode;
}

// Print all courses
void HashTable::printAllCourses() {
    // Create new vector for all the courses
    vector<Course> allCourses;

    // Iterate through all nodes in the hash table
    for (auto& currentNode : nodes) {
        // Start with the current node in the iteration
        Node* current = &currentNode;
        // Traverse the linked list at the current node
        
        while (current != nullptr) {
            // Check if the node is not an empty slot
            if (current->key != UINT_MAX) {
                // Add the course to the vector
                allCourses.push_back(current->course);
            }
            // Move to the next node in the linked list
            current = current->next;
        }
    }

    // Sort the courses alphanumerically based on course number
    sort(allCourses.begin(), allCourses.end(), [](const Course& a, const Course& b) {
        return a.courseNumber < b.courseNumber;
    });

    // Print the sorted list of courses
    for (const auto& course : allCourses) {
        cout << course.courseNumber << ", " << course.title << endl;
    }
}

// Print prerequisites
void HashTable::printPrerequisites(const std::vector<std::string>& prerequisites) {

     // Check if the prerequisites vector is not empty
    if (!prerequisites.empty()) {
        cout << "Prerequisites:" << endl;

        // Iterate through each prerequisite and print it
        for (const auto& prereq : prerequisites) {
            cout << prereq << endl;
        }
    }
}

// Print course
void HashTable::printCourse(const std::string& courseNumber) {

    // Find the node corresponding to the given courseNumber
    Node* node = findNode(courseNumber);

    // Check if the node is found
    if (node != nullptr) {

        // Print Course Number and Title
        cout << "Course Number: " << node->course.courseNumber
             << " | Title: " << node->course.title << endl;

        // Print prerequisites on the same line, separated by a comma
        cout << "Prerequisites: ";

        // Iterate through prerequisites and print them
        for (size_t i = 0; i < node->course.prerequisites.size(); ++i) {
            cout << node->course.prerequisites[i];

            // Add a comma if there are more prerequisites
            if (i < node->course.prerequisites.size() - 1) {
                cout << ", ";
            }
        }
        cout << endl;
    } else {
        // Prints a message if the course is not found
        cout << "Course not found." << endl;
    }
}

// Display course information
void displayCourse(const Course& course) {
    // Print Course Number and Title
    cout << course.courseNumber << ", " << course.title << endl;
}

// Load data from the CSV file into the hash table
void HashTable::loadCourses(const string& filePath) {
    try {
        // Create a CSV parser object from the given file pat
        csv::Parser file = csv::Parser(filePath);

        // Get the header (first row) of the CSV file
        std::vector<std::string> header = file.getHeader();

        // Define indices for columns in the CSV file
        unsigned int courseNumberIndex, titleIndex, prereq1Index, prereq2Index;

        // Finds the indices of the columns in the header
        for (unsigned int i = 0; i < header.size(); ++i) {
            if (header[i] == "course") {
                courseNumberIndex = i;
            } else if (header[i] == "title") {
                titleIndex = i;
            } else if (header[i] == "prereq1") {
                prereq1Index = i;
            } else if (header[i] == "prereq2") {
                prereq2Index = i;
            }
        }

        // Iterate through each row in the CSV file
        for (unsigned int i = 0; i < file.rowCount(); ++i) {
            Course course;
            course.courseNumber = file[i][courseNumberIndex];
            course.title = file[i][titleIndex];

            // Handles multiple prerequisites
            if (file[i][prereq1Index] != "na") {
                course.prerequisites.push_back(file[i][prereq1Index]);
            }
            if (file[i][prereq2Index] != "na") {
                course.prerequisites.push_back(file[i][prereq2Index]);
            }

            // Insert the course into the hash table
            insertCourse(course);  

            // Print information about the loaded course and its prerequisites
            cout << "Loaded Course: " << course.courseNumber << " | Prerequisites: ";
            for (const auto& prereq : course.prerequisites) {
                cout << prereq << " ";
            }
            cout << endl;
        }

        cout << "Courses loaded successfully." << endl;
    } catch (const csv::Error& e) {
        cerr << e.what() << endl;
    }
}



int main() { 
    // Create a new instance of the HashTable class
    HashTable* courseTable = new HashTable();

    int choice = 0;
    while (true) {
        // Display menu options
        cout << "1. Load Data Structure." << endl;
        cout << "2. Print Course List." << endl;
        cout << "3. Print Course." << endl;
        cout << "9. Exit" << endl;
        cout << "What would you like to do? ";

        // Get user's choice
        cin >> choice;

        // Process user's choice using a switch statement
        switch(choice) {
            case 1:
                { 
                    // Prompt user for CSV file path
                    string csvPath;
                    cout << "Enter CSV file path: ";
                    cin >> csvPath;

                    // Load courses from the specified CSV file
                    courseTable->loadCourses(csvPath);
                    cout << "Courses loaded successfully." << endl;
                }
                break;

            case 2:
                // Print the list of all courses
                courseTable->printAllCourses();
                break;
            
            case 3:
                {
                    // Prompt user for the course numbe
                    string courseNumber;
                    cout << "What course do you want to know about? ";
                    cin >> courseNumber;

                    // Print information about the specified course
                    courseTable->printCourse(courseNumber);
                }
                break;

            case 9:
                // Exits out the program and deletes memory from coursetable
                cout << "Thank you for using the course planner!" << endl;
                delete courseTable;
                return 0;

            default:
                // Let user know the option is invalid
                cout << choice << " is not a valid option." << endl;
                break;
        }

        // clears input buffer
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    cout << "Thank you for using the course planner!" << endl;

    delete courseTable;

    return 0;
}
